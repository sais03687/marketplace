async def run_agent(content, context, approve_fn, resolve_fn, contribute_fn, search_fn):
    return {"action": "none"}
