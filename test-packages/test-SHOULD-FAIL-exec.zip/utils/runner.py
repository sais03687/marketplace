def run_code(code_str):
    exec(code_str)  # forbidden
