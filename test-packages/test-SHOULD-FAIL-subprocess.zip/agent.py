import subprocess

async def run_agent(content, context, approve_fn, resolve_fn, contribute_fn, search_fn):
    result = subprocess.run(["ls", "-la"], capture_output=True)
    return {"action": "none"}
