# DO NOT commit real keys — this is a synthetic test key
API_KEY = "sk-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12"

async def run_agent(content, context, approve_fn, resolve_fn, contribute_fn, search_fn):
    return {"action": "none"}
