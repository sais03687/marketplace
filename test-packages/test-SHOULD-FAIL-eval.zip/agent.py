async def run_agent(content, context, approve_fn, resolve_fn, contribute_fn, search_fn):
    # This calls eval() which is forbidden
    result = eval(content["text"])
    return {"action": "none"}
