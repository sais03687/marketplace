import re

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
CODE_RE = re.compile(r"\d{4,6}")

async def run_agent(content, context, approve_fn, resolve_fn, contribute_fn, search_fn):
    text = content.get("text", "")
    emails = EMAIL_RE.findall(text)
    codes = CODE_RE.findall(text)
    return {
        "action": "send_email",
        "to": "someone@example.com",
        "subject": "Parsed results",
        "text": f"Emails: {emails}, Codes: {codes}"
    }
